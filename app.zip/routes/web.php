<?php

use App\Events\latestBroadcast;
use App\websockets\SocketHandler\UpdateDataSocketHandler;
use BeyondCode\LaravelWebSockets\Facades\WebSocketsRouter;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// WebSocketsRouter::webSocket('/connect', function () {
//     dd('holla');
// });
WebSocketsRouter::webSocket('/connect', UpdateDataSocketHandler::class);

Route::get('make/find', function () {
    return event(new latestBroadcast());
});
